#include<iostream>
#include<vector>
using namespace std;

void displaysubset(const vector<int>& subset) {
    cout << "{";
    for (size_t i = 0; i < subset.size(); ++i) {
        cout << subset[i];
        if (i < subset.size() - 1) {
            cout << ", ";
        }
    }
    cout << "}" << endl;
}



void findsubsets(const vector<int>&set, vector<int>&subset, int sum, int currentindex, int targetsum)
{
    if(sum==targetsum)
    {
        displaysubset(subset);
        return;
    }
    if(currentindex==set.size()|| sum>targetsum)
    {
        return;
    }
   
    subset.push_back(set[currentindex]);
    findsubsets(set,subset,sum+set[currentindex],currentindex+1,targetsum);
    subset.pop_back();
    findsubsets(set, subset, sum, currentindex + 1, targetsum);
}

int main()
{
    int n;
    cout<<"enter the number of elements in the set";
    cin>>n;
   
    vector<int>set(n);
    cout<<"enter the elements in the set"<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>set[i];
    }
   
    int targetsum;
    cout<<"enter the target sum";
    cin>>targetsum;
   
    vector<int>subset;
    findsubsets(set,subset,0,0,targetsum);
   
    return 0;
}
