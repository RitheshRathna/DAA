#include <iostream>
#include <string>
#include <vector>

using namespace std;

const int ALPHABET_SIZE = 128;

void shiftTable(const string &pattern, vector<int> &shift) {
    int m = pattern.length();
   
    for (int i = 0; i < ALPHABET_SIZE; ++i) {
        shift[i] = m;
    }
   
    for (int i = 0; i < m - 1; ++i) {
        shift[pattern[i]] = m - 1 - i;
    }
}

int horspoolSearch(const string &text, const string &pattern) {
    int n = text.length();
    int m = pattern.length();
   
    vector<int> shift(ALPHABET_SIZE);
    shiftTable(pattern, shift);
   
    int i = m - 1;
    while (i < n) {
        int k = 0;
        while (k < m && pattern[m - 1 - k] == text[i - k]) {
            ++k;
        }
       
        if (k == m) {
            return i - m + 1;
            i += shift[text[i]];
        }
    }
   
    return -1;
}

int main() {
    string text, pattern;
   
    cout << "Enter the text: ";
    getline(cin, text);
   
    cout << "Enter the pattern: ";
    getline(cin, pattern);
   
    int result = horspoolSearch(text, pattern);
   
    if (result != -1) {
        cout << "Pattern found at position: " << result << endl;
    } else {
        cout << "Pattern not found." << endl;
    }
   
    return 0;
}
